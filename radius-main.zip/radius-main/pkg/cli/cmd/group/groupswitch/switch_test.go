/*
Copyright 2023 The Radius Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package groupswitch

import (
	"context"
	"errors"
	"path"
	"testing"

	"github.com/radius-project/radius/pkg/cli"
	"github.com/radius-project/radius/pkg/cli/clients"
	"github.com/radius-project/radius/pkg/cli/clierrors"
	"github.com/radius-project/radius/pkg/cli/connections"
	"github.com/radius-project/radius/pkg/cli/framework"
	"github.com/radius-project/radius/pkg/cli/output"
	"github.com/radius-project/radius/pkg/cli/workspaces"
	"github.com/radius-project/radius/pkg/ucp/api/v20231001preview"
	"github.com/radius-project/radius/test/radcli"
	"github.com/stretchr/testify/require"
	"go.uber.org/mock/gomock"
	"gopkg.in/yaml.v3"
)

func Test_CommandValidation(t *testing.T) {
	radcli.SharedCommandValidation(t, NewCommand)
}

func Test_Validate(t *testing.T) {
	configWithWorkspace := radcli.LoadConfigWithWorkspace(t)

	testcases := []radcli.ValidateInput{
		{
			Name:          "Switch Command with incorrect args",
			Input:         []string{},
			ExpectedValid: false,
			ConfigHolder: framework.ConfigHolder{
				ConfigFilePath: "",
				Config:         configWithWorkspace,
			},
		},
		{
			Name:          "Switch command with correct arguments",
			Input:         []string{"groupname"},
			ExpectedValid: true,
			ConfigHolder: framework.ConfigHolder{
				ConfigFilePath: "",
				Config:         configWithWorkspace,
			},
		},
		{
			Name:          "Switch command with non-editable workspace invalid",
			Input:         []string{"groupname"},
			ExpectedValid: false,
			ConfigHolder: framework.ConfigHolder{
				ConfigFilePath: "",
				Config:         radcli.LoadEmptyConfig(t),
			},
		},
	}
	radcli.SharedValidateValidation(t, NewCommand, testcases)
}

func Test_Run(t *testing.T) {
	t.Run("Switch resource group", func(t *testing.T) {
		t.Run("Success", func(t *testing.T) {
			configPath := path.Join(t.TempDir(), "config.yaml")

			yamlData, err := yaml.Marshal(map[string]any{
				"workspaces": cli.WorkspaceSection{
					Default: "b",
					Items: map[string]workspaces.Workspace{
						"a": {
							Connection: map[string]any{
								"kind":    workspaces.KindKubernetes,
								"context": "my-context",
							},
							Source: workspaces.SourceUserConfig,
							Scope:  "/planes/radius/local/resourceGroups/a",
						},
						"b": {
							Connection: map[string]any{
								"kind":    workspaces.KindKubernetes,
								"context": "my-context",
							},
							Source: workspaces.SourceUserConfig,
							Scope:  "/planes/radius/local/resourceGroups/b",
						},
					},
				},
			})
			require.NoError(t, err)

			config := radcli.LoadConfig(t, string(yamlData))
			config.SetConfigFile(configPath)

			expectedConfig := cli.WorkspaceSection{
				Default: "b",
				Items: map[string]workspaces.Workspace{
					"a": {
						Name: "a",
						Connection: map[string]any{
							"kind":    workspaces.KindKubernetes,
							"context": "my-context",
						},
						Source: workspaces.SourceUserConfig,
						Scope:  "/planes/radius/local/resourceGroups/a",
					},
					"b": {
						Name: "b",
						Connection: map[string]any{
							"kind":    workspaces.KindKubernetes,
							"context": "my-context",
						},
						Source: workspaces.SourceUserConfig,
						Scope:  "/planes/radius/local/resourceGroups/a",
					},
				},
			}

			testResourceGroup := v20231001preview.ResourceGroupResource{}

			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			appManagementClient := clients.NewMockApplicationsManagementClient(ctrl)
			appManagementClient.EXPECT().GetResourceGroup(gomock.Any(), gomock.Any(), "a").Return(testResourceGroup, nil)

			workspace := &workspaces.Workspace{
				Name: "b",
				Connection: map[string]any{
					"kind":    workspaces.KindKubernetes,
					"context": "my-context",
				},
				Scope: "/planes/radius/local/resourceGroups/b",
			}

			outputSink := &output.MockOutput{}
			runner := &Runner{
				ConfigHolder: &framework.ConfigHolder{
					Config:         config,
					ConfigFilePath: configPath,
				},
				ConnectionFactory:    &connections.MockFactory{ApplicationsManagementClient: appManagementClient},
				Workspace:            workspace,
				UCPResourceGroupName: "a",
				Output:               outputSink,
			}

			err = runner.Run(context.Background())
			require.NoError(t, err)

			actualConfig, err := cli.ReadWorkspaceSection(config)
			require.NoError(t, err)
			require.Equal(t, expectedConfig, actualConfig)

			expected := []any{
				output.LogOutput{
					Format: "Switched to resource group %q",
					Params: []any{"a"},
				},
			}

			require.Equal(t, expected, outputSink.Writes)

		})

		t.Run("Switch (not existent)", func(t *testing.T) {
			configPath := path.Join(t.TempDir(), "config.yaml")

			yamlData, err := yaml.Marshal(map[string]any{
				"workspaces": cli.WorkspaceSection{
					Default: "b",
					Items: map[string]workspaces.Workspace{

						"b": {
							Connection: map[string]any{
								"kind":    workspaces.KindKubernetes,
								"context": "my-context",
							},
							Source: workspaces.SourceUserConfig,
							Scope:  "/planes/radius/local/resourceGroups/b",
						},
					},
				},
			})

			config := radcli.LoadConfig(t, string(yamlData))
			config.SetConfigFile(configPath)
			require.NoError(t, err)

			testResourceGroup := v20231001preview.ResourceGroupResource{}

			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			appManagementClient := clients.NewMockApplicationsManagementClient(ctrl)
			appManagementClient.EXPECT().GetResourceGroup(gomock.Any(), gomock.Any(), "c").Return(testResourceGroup, errors.New("resource group doesnt exist"))

			workspace := &workspaces.Workspace{
				Name: "b",
				Connection: map[string]any{
					"kind":    workspaces.KindKubernetes,
					"context": "my-context",
				},
				Source: workspaces.SourceUserConfig,
				Scope:  "/planes/radius/local/resourceGroups/b",
			}

			runner := &Runner{
				ConfigHolder: &framework.ConfigHolder{
					Config:         config,
					ConfigFilePath: configPath,
				},
				ConnectionFactory:    &connections.MockFactory{ApplicationsManagementClient: appManagementClient},
				Workspace:            workspace,
				UCPResourceGroupName: "c",
			}

			expected := clierrors.Message("The resource group %q does not exist. Run `rad group create` or `rad init` and try again.", runner.UCPResourceGroupName)
			err = runner.Run(context.Background())
			require.Equal(t, expected, err)
		})
	})
}
